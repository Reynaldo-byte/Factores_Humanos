<?php
	$serverName = 'localhost';
	
	$con = mysqli_connect($serverName,'root', '123456','spa');

?>