<?php 
 Header("Location: formularios/frm_Inicio_de_Sesion.php");

?>